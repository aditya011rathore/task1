from django.urls import path, include
from project_app.views import *

urlpatterns = [
    path('login',user_login),
    path('signup',signup),
    path('user_detail_page',user_detail_page),
    path('logout',user_logout),
    path('delete_user',delete_user),
    path('edit_users',edit_users)
]
