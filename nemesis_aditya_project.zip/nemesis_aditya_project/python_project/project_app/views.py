from django.shortcuts import render,redirect
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from project_app.models import *
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect


# Create your views here.

@csrf_exempt
def signup(request):
    if request.method=="POST":
       	username = request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        cnf_pass=request.POST.get('cnf_pass')
        address=request.POST.get('address')
        if password==cnf_pass:
            if User.objects.filter(username=username).exists():
                messages.success(request, 'Username Taken Before')
                
            elif User.objects.filter(email=email).exists():
                messages.success(request, 'Email Taken Before')
                
            else:
                user=User.objects.create_user(username=username,email=email,password=password)
                user.save()
                candidate=SignUp.objects.create(username=username,email=email,password=password,address=address)
                candidate.save()
                messages.success(request, 'User Created Successfully')
                return render(request,"login.html")
        else:
        	messages.success(request, 'Password is not Matching')
        return render(request,"signup.html")
    else:
        return render(request,"signup.html")


@csrf_exempt
def user_login(request):
    data={}
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user=authenticate(request,username=username,password=password)
        if user:
            login(request,user)
            request.session["username"]=username
            return HttpResponseRedirect("user_detail_page")
        else:
            data["error"]="username or password is incorrect"
            res=render(request,"login.html",data)
            return (res)
    else:
        return render(request,"login.html",data)


def user_detail_page(request):
	context={
			'data':SignUp.objects.all()
	}
	return render(request, 'user_detail_page.html',context)

def user_logout(request):
    logout(request)
    return HttpResponseRedirect("login")


def delete_user(request):
	user_detail = SignUp.objects.filter(id=request.GET.get('i')).delete()
	messages.success(request, 'User Deleted Successfully')
	return HttpResponseRedirect('user_detail_page')
	


@csrf_exempt
def edit_users(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		email = request.POST.get('email')
		address = request.POST.get('address')
		SignUp.objects.create(username=username,email=email, address=address).save()
	return HttpResponseRedirect('user_detail_page')
